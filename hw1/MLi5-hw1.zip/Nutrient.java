//Michell Li
//MLi5
package hw1;

public class Nutrient {
	String nutrientCode;
	String nutrientName;
	String nutrientUom;
	
	//constructor
	public Nutrient(String nutrientCode, String nutrientName, String nutrientUom) {
		super();
		this.nutrientCode = nutrientCode;
		this.nutrientName = nutrientName;
		this.nutrientUom = nutrientUom;
	}
	
	

}
