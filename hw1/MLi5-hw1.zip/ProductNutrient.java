//Michell Li
//MLi5
package hw1;

public class ProductNutrient {
	String ndbNumber;
	String nutrientCode;
	String nutrientName;
	float quantity;
	String nutrientUom;
	
	//constructor....omit super call???
	public ProductNutrient(String ndbNumber, String nutrientCode, String nutrientName, float quantity,
			String nutrientUom) {
		super();
		this.ndbNumber = ndbNumber;
		this.nutrientCode = nutrientCode;
		this.nutrientName = nutrientName;
		this.quantity = quantity;
		this.nutrientUom = nutrientUom;
	}
	
	
	

}
